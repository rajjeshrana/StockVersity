"""
StockVersity Scanner Pro

Market Data Parser

Converts Upstox WebSocket V3 feed
into internal Tick objects.
"""

from __future__ import annotations

import logging

from datetime import datetime
from typing import Any, Dict, List, Optional

from .models import Tick

logger = logging.getLogger(__name__)


class MarketDataParser:
    """
    Converts broker feed into Tick model.
    """

    def __init__(self):

        self.total_messages = 0
        self.total_ticks = 0
        self.failed_messages = 0

    # =====================================================
    # ENTRY POINT
    # =====================================================

    def parse(
        self,
        message: Any,
    ) -> Optional[List[Tick]]:

        self.total_messages += 1

        try:

            if message is None:
                return None

            #
            # SDK sometimes returns protobuf-decoded object,
            # sometimes dict depending on implementation.
            #

            if hasattr(message, "to_dict"):

                message = message.to_dict()

            if not isinstance(message, dict):

                return None

            return self._parse_feed(message)

        except Exception:

            self.failed_messages += 1

            logger.exception(
                "Unable to parse websocket message."
            )

            return None

    # =====================================================
    # FEED PARSER
    # =====================================================

    def _parse_feed(
        self,
        data: Dict,
    ) -> List[Tick]:

        ticks: List[Tick] = []

        feeds = data.get("feeds", {})

        if not feeds:
            return ticks

        for instrument_key, payload in feeds.items():

            tick = self._parse_instrument(
                instrument_key,
                payload,
            )

            if tick is not None:

                ticks.append(tick)

                self.total_ticks += 1

        return ticks

    # =====================================================
    # INSTRUMENT
    # =====================================================

    def _parse_instrument(
        self,
        instrument_key: str,
        payload: Dict,
    ) -> Optional[Tick]:

        #
        # Upstox V3 feed stores market data
        # inside "ff" (full feed) or "ltpc"
        #

        full_feed = payload.get("ff")

        if full_feed:

            return self._parse_full_feed(
                instrument_key,
                full_feed,
            )

        ltpc = payload.get("ltpc")

        if ltpc:

            return self._parse_ltpc(
                instrument_key,
                ltpc,
            )

        return None
        # =====================================================
    # FULL FEED
    # =====================================================

    def _parse_full_feed(
        self,
        instrument_key: str,
        feed: Dict,
    ) -> Tick:

        market = feed.get("marketFF", {})

        ltpc = market.get("ltpc", {})
        e_feed = market.get("eFeedDetails", {})

        ohlc_list = market.get("marketOHLC", {}).get(
            "ohlc",
            [],
        )

        ohlc = {}

        for item in ohlc_list:

            interval = item.get("interval", "")

            ohlc[interval] = item

        bid_ask = market.get("marketLevel", {}).get(
            "bidAskQuote",
            [],
        )

        best_bid = bid_ask[0] if bid_ask else {}
        best_ask = bid_ask[-1] if bid_ask else {}

        timestamp = ltpc.get("ltt")

        if timestamp:

            try:

                timestamp = datetime.fromtimestamp(
                    timestamp / 1000
                )

            except Exception:

                timestamp = datetime.now()

        else:

            timestamp = datetime.now()

        return Tick(

            instrument_key=instrument_key,

            timestamp=timestamp,

            last_price=float(
                ltpc.get("ltp", 0)
            ),

            volume=int(
                e_feed.get("vtt", 0)
            ),

            open=float(
                ohlc.get("1d", {}).get("open", 0)
            ),

            high=float(
                ohlc.get("1d", {}).get("high", 0)
            ),

            low=float(
                ohlc.get("1d", {}).get("low", 0)
            ),

            close=float(
                ohlc.get("1d", {}).get("close", 0)
            ),

            bid=float(
                best_bid.get("bidP", 0)
            ),

            ask=float(
                best_ask.get("askP", 0)
            ),

            bid_qty=int(
                best_bid.get("bidQ", 0)
            ),

            ask_qty=int(
                best_ask.get("askQ", 0)
            ),

            open_interest=int(
                e_feed.get("oi", 0)
            ),

        )

    # =====================================================
    # LTPC FEED
    # =====================================================

    def _parse_ltpc(
        self,
        instrument_key: str,
        ltpc: Dict,
    ) -> Tick:

        timestamp = ltpc.get("ltt")

        if timestamp:

            try:

                timestamp = datetime.fromtimestamp(
                    timestamp / 1000
                )

            except Exception:

                timestamp = datetime.now()

        else:

            timestamp = datetime.now()

        return Tick(

            instrument_key=instrument_key,

            timestamp=timestamp,

            last_price=float(
                ltpc.get("ltp", 0)
            ),

            volume=0,

            open=0,

            high=0,

            low=0,

            close=0,

            bid=0,

            ask=0,

            bid_qty=0,

            ask_qty=0,

            open_interest=0,

        )
        # =====================================================
    # RESET STATISTICS
    # =====================================================

    def reset(self) -> None:

        self.total_messages = 0
        self.total_ticks = 0
        self.failed_messages = 0

    # =====================================================
    # STATISTICS
    # =====================================================

    def statistics(self) -> Dict[str, int]:

        return {

            "messages": self.total_messages,

            "ticks": self.total_ticks,

            "failed": self.failed_messages,

        }

    # =====================================================
    # HEALTH
    # =====================================================

    @property
    def healthy(self) -> bool:

        return self.failed_messages == 0

    # =====================================================
    # SUCCESS RATE
    # =====================================================

    @property
    def success_rate(self) -> float:

        if self.total_messages == 0:

            return 100.0

        return (

            (
                self.total_messages
                - self.failed_messages
            )
            / self.total_messages
        ) * 100.0

    # =====================================================
    # DIAGNOSTICS
    # =====================================================

    def diagnostics(self) -> Dict[str, Any]:

        return {

            "healthy": self.healthy,

            "messages": self.total_messages,

            "ticks": self.total_ticks,

            "failed": self.failed_messages,

            "success_rate": round(

                self.success_rate,

                2,

            ),

        }

    # =====================================================
    # VALIDATION
    # =====================================================

    def validate_tick(

        self,

        tick: Tick,

    ) -> bool:

        if tick is None:

            return False

        if not tick.instrument_key:

            return False

        if tick.last_price <= 0:

            return False

        return True

    # =====================================================
    # PARSE ONE
    # =====================================================

    def parse_one(

        self,

        message: Any,

    ) -> Optional[Tick]:

        ticks = self.parse(message)

        if not ticks:

            return None

        return ticks[0]

    # =====================================================
    # LENGTH
    # =====================================================

    def __len__(self):

        return self.total_ticks

    # =====================================================
    # STRING
    # =====================================================

    def __str__(self):

        return (

            "MarketDataParser("

            f"messages={self.total_messages}, "

            f"ticks={self.total_ticks}, "

            f"failed={self.failed_messages}"

            ")"

        )

    # =====================================================
    # REPR
    # =====================================================

    def __repr__(self):

        return (

            "<MarketDataParser "

            f"messages={self.total_messages} "

            f"ticks={self.total_ticks} "

            f"failed={self.failed_messages}>"

        )


# =====================================================
# DEFAULT PARSER
# =====================================================

default_parser = MarketDataParser()


# =====================================================
# MODULE EXPORTS
# =====================================================

__all__ = [

    "MarketDataParser",

    "default_parser",

]