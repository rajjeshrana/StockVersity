﻿"""
StockVersity Pro
Main Application Window

File:
    ui/app.py

Purpose:
    Central UI controller for StockVersity Pro.

Integrated modules:
    - Professional Dashboard
    - Professional Intraday Scanner
    - Sidebar navigation
    - Header
    - Market session status
    - Status bar
    - Scanner signal routing
    - Stock selection routing
    - Keyboard shortcuts

Architecture:
    UI pages remain separated from market-data and
    scanner-engine services.
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

from PySide6.QtCore import (
    QEasingCurve,
    QDateTime,
    QPropertyAnimation,
    Qt,
    QTime,
    QTimer,
)

from PySide6.QtGui import (
    QAction,
    QCloseEvent,
    QFont,
    QKeySequence,
)

from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

# ==========================================================
# STOCKVERSITY PAGES
# ==========================================================

from ui.pages.dashboard_page import DashboardPage

from ui.pages.intraday_page import (
    IntradayScannerPage,
)


logger = logging.getLogger(__name__)


# ==========================================================
# APPLICATION CONSTANTS
# ==========================================================

APP_NAME = "StockVersity Pro"

APP_VERSION = "1.0"

WINDOW_MIN_WIDTH = 1280

WINDOW_MIN_HEIGHT = 760

SIDEBAR_EXPANDED_WIDTH = 225

SIDEBAR_COLLAPSED_WIDTH = 72

HEADER_HEIGHT = 68

STATUSBAR_HEIGHT = 30


# ==========================================================
# DESIGN SYSTEM
# ==========================================================

BACKGROUND = "#07101D"

BACKGROUND_SECONDARY = "#0A1423"

SURFACE = "#0D1828"

SURFACE_HOVER = "#122238"

BORDER = "#182A42"

BORDER_LIGHT = "#213650"

TEXT_PRIMARY = "#F3F7FC"

TEXT_SECONDARY = "#AAB8CB"

TEXT_MUTED = "#65758C"

BLUE = "#4C8DFF"

CYAN = "#35D0FF"

GREEN = "#2ED6A1"

RED = "#FF5D73"

ORANGE = "#FFB547"

PURPLE = "#9A7BFF"

FONT_FAMILY = "Segoe UI"


# ==========================================================
# PAGE METADATA
# ==========================================================

PAGE_METADATA = {

    "dashboard": (
        "Dashboard",
        "Market intelligence, scanner opportunities "
        "& trading setup analysis",
    ),

    "market": (
        "Market",
        "Index structure, breadth and market regime",
    ),

    "heatmap": (
        "Market Heatmap",
        "NSE stock and sector performance map",
    ),

    "intraday": (
        "Intraday Scanner",
        "High-momentum NSE opportunities "
        "from 1 minute to 45 minute timeframes",
    ),

    "swing": (
        "Swing Scanner",
        "Multi-day breakout and momentum opportunities",
    ),

    "positional": (
        "Positional Scanner",
        "Higher-timeframe trend and breakout opportunities",
    ),

    "sectors": (
        "Sector Rotation",
        "Relative strength and capital rotation intelligence",
    ),

    "institutional": (
        "FII / DII",
        "Institutional participation and "
        "cash-market positioning",
    ),

    "derivatives": (
        "Derivatives",
        "Futures and options positioning intelligence",
    ),

    "watchlist": (
        "Smart Watchlist",
        "Personal stocks ranked by setup quality",
    ),

    "alerts": (
        "Alert Center",
        "Scanner signals and market notifications",
    ),
}


# ==========================================================
# PLACEHOLDER PAGE
# ==========================================================

class PlaceholderPage(QWidget):
    """
    Temporary high-quality shell for modules that have not
    yet been replaced by their dedicated page.
    """

    def __init__(
        self,
        title: str,
        subtitle: str,
        icon: str = "â—†",
        parent: Optional[QWidget] = None,
    ) -> None:

        super().__init__(parent)

        self.setObjectName(
            "PlaceholderPage"
        )

        self.setStyleSheet(
            f"""
            QWidget#PlaceholderPage {{
                background: {BACKGROUND};
            }}
            """
        )

        root = QVBoxLayout(self)

        root.setContentsMargins(
            32,
            28,
            32,
            28,
        )

        root.setSpacing(12)

        root.addStretch(1)

        card = QFrame()

        card.setObjectName(
            "PlaceholderCard"
        )

        card.setMaximumWidth(
            620
        )

        card.setStyleSheet(
            f"""
            QFrame#PlaceholderCard {{
                background:
                    qlineargradient(
                        x1:0,
                        y1:0,
                        x2:1,
                        y2:1,
                        stop:0 {SURFACE},
                        stop:1 {BACKGROUND_SECONDARY}
                    );

                border:
                    1px solid {BORDER};

                border-radius: 16px;
            }}
            """
        )

        card_layout = QVBoxLayout(
            card
        )

        card_layout.setContentsMargins(
            38,
            34,
            38,
            34,
        )

        card_layout.setSpacing(10)

        icon_label = QLabel(
            icon
        )

        icon_label.setAlignment(
            Qt.AlignCenter
        )

        icon_label.setStyleSheet(
            f"""
            color: {CYAN};
            font-size: 34px;
            font-weight: 900;
            """
        )

        card_layout.addWidget(
            icon_label
        )

        title_label = QLabel(
            title
        )

        title_label.setAlignment(
            Qt.AlignCenter
        )

        title_label.setStyleSheet(
            f"""
            color: {TEXT_PRIMARY};
            font-size: 25px;
            font-weight: 900;
            """
        )

        card_layout.addWidget(
            title_label
        )

        subtitle_label = QLabel(
            subtitle
        )

        subtitle_label.setAlignment(
            Qt.AlignCenter
        )

        subtitle_label.setWordWrap(
            True
        )

        subtitle_label.setStyleSheet(
            f"""
            color: {TEXT_MUTED};
            font-size: 10px;
            """
        )

        card_layout.addWidget(
            subtitle_label
        )

        ready_badge = QLabel(
            "MODULE ARCHITECTURE READY"
        )

        ready_badge.setAlignment(
            Qt.AlignCenter
        )

        ready_badge.setStyleSheet(
            f"""
            QLabel {{
                color: {CYAN};

                background:
                    rgba(53,208,255,0.055);

                border:
                    1px solid rgba(53,208,255,0.18);

                border-radius: 7px;

                padding: 7px 12px;

                font-size: 7px;

                font-weight: 900;
            }}
            """
        )

        card_layout.addWidget(
            ready_badge,
            alignment=Qt.AlignCenter,
        )

        root.addWidget(
            card,
            alignment=Qt.AlignCenter,
        )

        root.addStretch(1)


# ==========================================================
# NAVIGATION BUTTON
# ==========================================================

class NavigationButton(QPushButton):

    def __init__(
        self,
        key: str,
        icon_text: str,
        title: str,
        parent: Optional[QWidget] = None,
    ) -> None:

        super().__init__(parent)

        self.key = key

        self.icon_text = icon_text

        self.title_text = title

        self._active = False

        self._collapsed = False

        self.setCursor(
            Qt.PointingHandCursor
        )

        self.setMinimumHeight(
            46
        )

        self.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Fixed,
        )

        self._apply_text()

        self._apply_style()

    # ======================================================
    # TEXT
    # ======================================================

    def _apply_text(
        self,
    ) -> None:

        if self._collapsed:

            self.setText(
                self.icon_text
            )

        else:

            self.setText(
                f"{self.icon_text}    "
                f"{self.title_text}"
            )

    # ======================================================
    # COLLAPSE
    # ======================================================

    def set_collapsed(
        self,
        collapsed: bool,
    ) -> None:

        self._collapsed = collapsed

        self._apply_text()

        if collapsed:

            self.setToolTip(
                self.title_text
            )

        else:

            self.setToolTip(
                ""
            )

    # ======================================================
    # ACTIVE
    # ======================================================

    def set_active(
        self,
        active: bool,
    ) -> None:

        self._active = active

        self._apply_style()

    # ======================================================
    # STYLE
    # ======================================================

    def _apply_style(
        self,
    ) -> None:

        if self._active:

            self.setStyleSheet(
                f"""
                QPushButton {{
                    color: {TEXT_PRIMARY};

                    background:
                        rgba(76,141,255,0.14);

                    border:
                        1px solid rgba(76,141,255,0.24);

                    border-radius: 9px;

                    text-align: left;

                    padding-left: 15px;

                    font-family: "{FONT_FAMILY}";

                    font-size: 10px;

                    font-weight: 800;
                }}

                QPushButton:hover {{
                    background:
                        rgba(76,141,255,0.19);
                }}
                """
            )

        else:

            self.setStyleSheet(
                f"""
                QPushButton {{
                    color: {TEXT_SECONDARY};

                    background: transparent;

                    border:
                        1px solid transparent;

                    border-radius: 9px;

                    text-align: left;

                    padding-left: 15px;

                    font-family: "{FONT_FAMILY}";

                    font-size: 10px;

                    font-weight: 700;
                }}

                QPushButton:hover {{
                    color: {TEXT_PRIMARY};

                    background:
                        rgba(255,255,255,0.035);

                    border:
                        1px solid rgba(255,255,255,0.045);
                }}
                """
            )


# ==========================================================
# SIDEBAR SECTION
# ==========================================================

class SidebarSectionLabel(QLabel):

    def __init__(
        self,
        text: str,
        parent: Optional[QWidget] = None,
    ) -> None:

        super().__init__(
            text,
            parent,
        )

        self._original_text = text

        self.setFixedHeight(
            25
        )

        self.setStyleSheet(
            f"""
            color: {TEXT_MUTED};
            font-size: 7px;
            font-weight: 900;
            padding-left: 8px;
            """
        )

    def set_collapsed(
        self,
        collapsed: bool,
    ) -> None:

        if collapsed:

            self.setText(
                ""
            )

            self.setFixedHeight(
                8
            )

        else:

            self.setText(
                self._original_text
            )

            self.setFixedHeight(
                25
            )


# ==========================================================
# SIDEBAR
# ==========================================================

class StockVersitySidebar(QFrame):

    from PySide6.QtCore import Signal

    page_requested = Signal(str)

    collapse_requested = Signal()

    def __init__(
        self,
        parent: Optional[QWidget] = None,
    ) -> None:

        super().__init__(parent)

        self._collapsed = False

        self.buttons: Dict[
            str,
            NavigationButton,
        ] = {}

        self.section_labels = []

        self.setObjectName(
            "StockVersitySidebar"
        )

        self.setFixedWidth(
            SIDEBAR_EXPANDED_WIDTH
        )

        self.setStyleSheet(
            f"""
            QFrame#StockVersitySidebar {{
                background: {BACKGROUND_SECONDARY};
                border: none;
                border-right: 1px solid {BORDER};
            }}
            """
        )

        self._build_ui()

    # ======================================================
    # BUILD
    # ======================================================

    def _build_ui(
        self,
    ) -> None:

        layout = QVBoxLayout(self)

        layout.setContentsMargins(
            12,
            14,
            12,
            14,
        )

        layout.setSpacing(
            5
        )

        # --------------------------------------------------
        # BRAND
        # --------------------------------------------------

        brand = QWidget()

        self.brand_layout = QHBoxLayout(
            brand
        )

        self.brand_layout.setContentsMargins(
            4,
            0,
            4,
            12,
        )

        self.brand_layout.setSpacing(
            9
        )

        self.logo = QLabel(
            "SV"
        )

        self.logo.setAlignment(
            Qt.AlignCenter
        )

        self.logo.setFixedSize(
            38,
            38,
        )

        self.logo.setStyleSheet(
            f"""
            QLabel {{
                color: white;

                background:
                    qlineargradient(
                        x1:0,
                        y1:0,
                        x2:1,
                        y2:1,
                        stop:0 {BLUE},
                        stop:1 {PURPLE}
                    );

                border-radius: 10px;

                font-size: 11px;

                font-weight: 900;
            }}
            """
        )

        self.brand_layout.addWidget(
            self.logo
        )

        self.brand_text_widget = QWidget()

        brand_text_layout = QVBoxLayout(
            self.brand_text_widget
        )

        brand_text_layout.setContentsMargins(
            0,
            0,
            0,
            0,
        )

        brand_text_layout.setSpacing(
            0
        )

        self.brand_title = QLabel(
            "STOCKVERSITY"
        )

        self.brand_title.setStyleSheet(
            f"""
            color: {TEXT_PRIMARY};
            font-size: 11px;
            font-weight: 900;
            """
        )

        brand_text_layout.addWidget(
            self.brand_title
        )

        self.brand_subtitle = QLabel(
            "PRO TERMINAL"
        )

        self.brand_subtitle.setStyleSheet(
            f"""
            color: {CYAN};
            font-size: 7px;
            font-weight: 800;
            """
        )

        brand_text_layout.addWidget(
            self.brand_subtitle
        )

        self.brand_layout.addWidget(
            self.brand_text_widget
        )

        self.brand_layout.addStretch(1)

        layout.addWidget(
            brand
        )

        # --------------------------------------------------
        # MARKET
        # --------------------------------------------------

        self._add_section(
            layout,
            "MARKET",
        )

        self._add_button(
            layout,
            "dashboard",
            "â—†",
            "Dashboard",
        )

        self._add_button(
            layout,
            "market",
            "â—ˆ",
            "Market",
        )

        self._add_button(
            layout,
            "heatmap",
            "â–¦",
            "Heatmap",
        )

        # --------------------------------------------------
        # SCANNERS
        # --------------------------------------------------

        self._add_section(
            layout,
            "SCANNERS",
        )

        self._add_button(
            layout,
            "intraday",
            "âš¡",
            "Intraday",
        )

        self._add_button(
            layout,
            "swing",
            "â†—",
            "Swing",
        )

        self._add_button(
            layout,
            "positional",
            "â—Ž",
            "Positional",
        )

        # --------------------------------------------------
        # INTELLIGENCE
        # --------------------------------------------------

        self._add_section(
            layout,
            "INTELLIGENCE",
        )

        self._add_button(
            layout,
            "sectors",
            "â—«",
            "Sector Rotation",
        )

        self._add_button(
            layout,
            "institutional",
            "â—‰",
            "FII / DII",
        )

        self._add_button(
            layout,
            "derivatives",
            "âŒ",
            "Derivatives",
        )

        # --------------------------------------------------
        # WORKSPACE
        # --------------------------------------------------

        self._add_section(
            layout,
            "WORKSPACE",
        )

        self._add_button(
            layout,
            "watchlist",
            "â˜…",
            "Watchlist",
        )

        self._add_button(
            layout,
            "alerts",
            "â—",
            "Alerts",
        )

        layout.addStretch(1)

        # --------------------------------------------------
        # COLLAPSE
        # --------------------------------------------------

        self.collapse_button = QPushButton(
            "â€¹   Collapse"
        )

        self.collapse_button.setCursor(
            Qt.PointingHandCursor
        )

        self.collapse_button.setFixedHeight(
            38
        )

        self._style_collapse_button(
            collapsed=False
        )

        self.collapse_button.clicked.connect(
            self.collapse_requested.emit
        )

        layout.addWidget(
            self.collapse_button
        )

    # ======================================================
    # SECTION
    # ======================================================

    def _add_section(
        self,
        layout: QVBoxLayout,
        text: str,
    ) -> None:

        label = SidebarSectionLabel(
            text
        )

        self.section_labels.append(
            label
        )

        layout.addWidget(
            label
        )

    # ======================================================
    # BUTTON
    # ======================================================

    def _add_button(
        self,
        layout: QVBoxLayout,
        key: str,
        icon: str,
        title: str,
    ) -> None:

        button = NavigationButton(
            key,
            icon,
            title,
        )

        button.clicked.connect(
            lambda checked=False, page=key:
                self.page_requested.emit(
                    page
                )
        )

        self.buttons[
            key
        ] = button

        layout.addWidget(
            button
        )

    # ======================================================
    # ACTIVE PAGE
    # ======================================================

    def set_active_page(
        self,
        page_key: str,
    ) -> None:

        for key, button in (
            self.buttons.items()
        ):

            button.set_active(
                key == page_key
            )

    # ======================================================
    # COLLAPSE
    # ======================================================

    def set_collapsed(
        self,
        collapsed: bool,
    ) -> None:

        self._collapsed = collapsed

        for button in (
            self.buttons.values()
        ):

            button.set_collapsed(
                collapsed
            )

        for label in (
            self.section_labels
        ):

            label.set_collapsed(
                collapsed
            )

        self.brand_text_widget.setVisible(
            not collapsed
        )

        if collapsed:

            self.collapse_button.setText(
                "â€º"
            )

            self.collapse_button.setToolTip(
                "Expand sidebar"
            )

        else:

            self.collapse_button.setText(
                "â€¹   Collapse"
            )

            self.collapse_button.setToolTip(
                ""
            )

        self._style_collapse_button(
            collapsed
        )

    def _style_collapse_button(
        self,
        collapsed: bool,
    ) -> None:

        alignment = (
            "center"
            if collapsed
            else "left"
        )

        padding = (
            "0"
            if collapsed
            else "0 0 0 14px"
        )

        font_size = (
            "16px"
            if collapsed
            else "8px"
        )

        self.collapse_button.setStyleSheet(
            f"""
            QPushButton {{
                color: {TEXT_MUTED};

                background:
                    rgba(255,255,255,0.02);

                border:
                    1px solid {BORDER};

                border-radius: 8px;

                text-align: {alignment};

                padding: {padding};

                font-size: {font_size};

                font-weight: 800;
            }}

            QPushButton:hover {{
                color: {TEXT_PRIMARY};

                background:
                    rgba(255,255,255,0.045);
            }}
            """
        )
class MainWindow(QMainWindow):
    """Main application window for StockVersity Pro."""

    PAGE_TITLES = {
        "dashboard": "Dashboard",
        "market": "Market Overview",
        "heatmap": "Market Heatmap",
        "intraday": "Intraday Scanner",
        "swing": "Swing Scanner",
        "positional": "Positional Scanner",
        "sectors": "Sector Rotation",
        "institutional": "FII / DII",
        "derivatives": "Derivatives",
        "watchlist": "Watchlist",
        "alerts": "Alerts",
    }

    def __init__(
        self,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)

        self.pages: Dict[str, QWidget] = {}
        self.current_page_key = "dashboard"

        self.setWindowTitle(
            f"{APP_NAME} v{APP_VERSION}"
        )
        self.setMinimumSize(
            WINDOW_MIN_WIDTH,
            WINDOW_MIN_HEIGHT,
        )
        self.resize(
            1440,
            900,
        )

        self._build_ui()
        self.show_page("dashboard")

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)

        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.sidebar = StockVersitySidebar(self)
        self.sidebar.page_requested.connect(
            self.show_page
        )
        self.sidebar.collapse_requested.connect(
            self.toggle_sidebar
        )

        root_layout.addWidget(self.sidebar)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        self.header_title = QLabel("Dashboard")
        self.header_title.setFixedHeight(HEADER_HEIGHT)
        self.header_title.setContentsMargins(
            28,
            0,
            28,
            0,
        )
        self.header_title.setStyleSheet(
            """
            QLabel {
                background: #101622;
                color: #f4f7fb;
                border-bottom: 1px solid #263142;
                font-size: 20px;
                font-weight: 700;
            }
            """
        )

        self.stack = QStackedWidget()
        self.stack.setStyleSheet(
            """
            QStackedWidget {
                background: #0b1018;
            }
            """
        )

        content_layout.addWidget(self.header_title)
        content_layout.addWidget(self.stack, 1)

        root_layout.addWidget(content, 1)

        self.add_page(
            "dashboard",
            DashboardPage(),
        )
        self.add_page(
            "intraday",
            IntradayScannerPage(),
        )

    def add_page(
        self,
        page_key: str,
        page: QWidget,
    ) -> None:
        self.pages[page_key] = page
        self.stack.addWidget(page)

    def show_page(
        self,
        page_key: str,
    ) -> None:
        if page_key not in self.pages:
            self.add_page(
                page_key,
                self._create_placeholder_page(page_key),
            )

        self.current_page_key = page_key
        self.stack.setCurrentWidget(
            self.pages[page_key]
        )
        self.header_title.setText(
            self.PAGE_TITLES.get(
                page_key,
                page_key.replace("_", " ").title(),
            )
        )
        self.sidebar.set_active_page(page_key)

    def _create_placeholder_page(
        self,
        page_key: str,
    ) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignCenter)

        title = QLabel(
            self.PAGE_TITLES.get(
                page_key,
                page_key.replace("_", " ").title(),
            )
        )
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            """
            QLabel {
                color: #f4f7fb;
                font-size: 28px;
                font-weight: 700;
            }
            """
        )

        message = QLabel(
            "This page is ready for its next implementation."
        )
        message.setAlignment(Qt.AlignCenter)
        message.setStyleSheet(
            """
            QLabel {
                color: #93a4b8;
                font-size: 14px;
            }
            """
        )

        layout.addWidget(title)
        layout.addWidget(message)

        return page

    def toggle_sidebar(self) -> None:
        self.sidebar.set_collapsed(
            not self.sidebar._collapsed
        )

    def closeEvent(
        self,
        event: QCloseEvent,
    ) -> None:
        event.accept()

