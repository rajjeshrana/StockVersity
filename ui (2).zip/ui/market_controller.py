"""
=========================================================
StockVersity Scanner Pro
Powered by AI
Version : 4.0

File : ui/market_controller.py
=========================================================
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from PySide6.QtCore import (
    QObject,
    Signal,
    Slot,
    QTimer,
)

from ui.theme import current_theme


class MarketController(QObject):
    """
    Central Market Controller

    Responsibilities
    ----------------
    • Live NSE Market Data
    • Nifty
    • BankNifty
    • FinNifty
    • Midcap
    • India VIX
    • Market Breadth
    • Sector Rotation
    • Top Gainers
    • Top Losers
    • Market Status
    """

    marketUpdated = Signal(dict)

    marketStatusChanged = Signal(str)

    sectorUpdated = Signal(list)

    breadthUpdated = Signal(dict)

    indicesUpdated = Signal(dict)

    gainersUpdated = Signal(list)

    losersUpdated = Signal(list)

    statusChanged = Signal(str)

    statisticsUpdated = Signal(dict)

    def __init__(
        self,
        backend,
        dashboard=None,
        parent=None
    ):

        super().__init__(parent)

        self.backend = backend

        self.dashboard = dashboard

        self.market_open = False

        self.market_data = {}

        self.indices = {}

        self.sectors = []

        self.gainers = []

        self.losers = []

        self.breadth = {}

        self.last_update = None

        self._initialize()

    # =====================================================
    # INITIALIZATION
    # =====================================================

    def _initialize(self):

        self._discover_widgets()

        self._create_timers()

        self._connect_signals()

    # =====================================================
    # DISCOVER UI
    # =====================================================

    def _discover_widgets(self):

        self.cards = {}

        self.tables = {}

        if self.dashboard is None:

            return

        if not hasattr(

            self.dashboard,

            "findChildren"

        ):

            return

        for widget in self.dashboard.findChildren(QObject):

            name = widget.objectName()

            if not name:

                continue

            if "card" in name.lower():

                self.cards[name] = widget

            elif "table" in name.lower():

                self.tables[name] = widget

    # =====================================================
    # TIMERS
    # =====================================================

    def _create_timers(self):

        self.market_timer = QTimer(self)

        self.market_timer.timeout.connect(

            self.refresh_market

        )

        self.status_timer = QTimer(self)

        self.status_timer.timeout.connect(

            self.check_market_status

        )

    # =====================================================
    # SIGNALS
    # =====================================================

    def _connect_signals(self):

        pass

    # =====================================================
    # START
    # =====================================================

    def start(self):

        self.market_timer.start(

            5000

        )

        self.status_timer.start(

            30000

        )

        self.statusChanged.emit(

            "Market Controller Started"

        )

    # =====================================================
    # STOP
    # =====================================================

    def stop(self):

        self.market_timer.stop()

        self.status_timer.stop()

    # =====================================================
    # MARKET STATUS
    # =====================================================

    def check_market_status(self):

        now = datetime.now()

        if now.weekday() >= 5:

            status = "Closed"

        else:

            current = now.hour * 60 + now.minute

            open_time = 9 * 60 + 15

            close_time = 15 * 60 + 30

            if current < open_time:

                status = "Pre Open"

            elif current <= close_time:

                status = "Open"

            else:

                status = "Closed"

        self.market_open = status == "Open"

        self.marketStatusChanged.emit(

            status

        )

        self.statusChanged.emit(

            f"Market Status : {status}"

        )

    # =====================================================
    # REFRESH
    # =====================================================

    def refresh_market(self):

        try:

            self.market_data = self.backend.market_snapshot()

        except Exception:

            self.market_data = {}

            return

        self.last_update = datetime.now()

        self.update_indices()

        self.update_market_breadth()

        self.update_sectors()

        self.update_gainers()

        self.update_losers()

        self.marketUpdated.emit(

            self.market_data

        )

        self.update_statistics()

    # =====================================================
    # UPDATE INDICES
    # =====================================================

    def update_indices(self):

        self.indices = self.market_data.get(

            "indices",

            {}

        )

        self.indicesUpdated.emit(

            self.indices

        )

    # =====================================================
    # MARKET BREADTH
    # =====================================================

    def update_market_breadth(self):

        self.breadth = self.market_data.get(

            "breadth",

            {}

        )

        self.breadthUpdated.emit(

            self.breadth

        )

    # =====================================================
    # SECTORS
    # =====================================================

    def update_sectors(self):

        self.sectors = self.market_data.get(

            "sectors",

            []

        )

        self.sectorUpdated.emit(

            self.sectors

        )

    # =====================================================
    # GAINERS
    # =====================================================

    def update_gainers(self):

        self.gainers = self.market_data.get(

            "gainers",

            []

        )

        self.gainersUpdated.emit(

            self.gainers

        )

    # =====================================================
    # LOSERS
    # =====================================================

    def update_losers(self):

        self.losers = self.market_data.get(

            "losers",

            []

        )

        self.losersUpdated.emit(

            self.losers

        )
            # =====================================================
    # MARKET STATISTICS
    # =====================================================

    def update_statistics(self):

        statistics = {

            "market_open":

                self.market_open,

            "indices":

                len(self.indices),

            "sectors":

                len(self.sectors),

            "gainers":

                len(self.gainers),

            "losers":

                len(self.losers),

            "last_update":

                self.last_update,

        }

        self.statisticsUpdated.emit(

            statistics

        )

        self.update_cards(

            statistics

        )

        self.update_tables()

    # =====================================================
    # DASHBOARD CARDS
    # =====================================================

    def update_cards(

        self,

        statistics

    ):

        mapping = {

            "market_status_card":

                "Open" if statistics["market_open"] else "Closed",

            "sector_count_card":

                statistics["sectors"],

            "gainers_count_card":

                statistics["gainers"],

            "losers_count_card":

                statistics["losers"],

        }

        for card_name, value in mapping.items():

            if card_name not in self.cards:

                continue

            card = self.cards[card_name]

            if hasattr(

                card,

                "set_value"

            ):

                card.set_value(

                    str(value)

                )

    # =====================================================
    # TABLE UPDATES
    # =====================================================

    def update_tables(self):

        self._update_gainers_table()

        self._update_losers_table()

        self._update_sector_table()

    # =====================================================
    # GAINERS TABLE
    # =====================================================

    def _update_gainers_table(self):

        if "gainers_table" not in self.tables:

            return

        table = self.tables["gainers_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        for stock in self.gainers:

            row = [

                stock.get("symbol", ""),

                stock.get("price", ""),

                stock.get("change", ""),

                stock.get("change_percent", ""),

                stock.get("volume", ""),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # LOSERS TABLE
    # =====================================================

    def _update_losers_table(self):

        if "losers_table" not in self.tables:

            return

        table = self.tables["losers_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        for stock in self.losers:

            row = [

                stock.get("symbol", ""),

                stock.get("price", ""),

                stock.get("change", ""),

                stock.get("change_percent", ""),

                stock.get("volume", ""),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # SECTOR TABLE
    # =====================================================

    def _update_sector_table(self):

        if "sector_table" not in self.tables:

            return

        table = self.tables["sector_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        ranked = self.rank_sectors()

        for sector in ranked:

            row = [

                sector.get(

                    "sector",

                    ""

                ),

                sector.get(

                    "change",

                    ""

                ),

                sector.get(

                    "advance",

                    ""

                ),

                sector.get(

                    "decline",

                    ""

                ),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # SEARCH
    # =====================================================

    def search_stock(

        self,

        keyword: str

    ):

        keyword = keyword.upper()

        results = []

        universe = self.gainers + self.losers

        for stock in universe:

            symbol = str(

                stock.get(

                    "symbol",

                    ""

                )

            ).upper()

            company = str(

                stock.get(

                    "company",

                    ""

                )

            ).upper()

            if keyword in symbol or keyword in company:

                results.append(stock)

        return results

    # =====================================================
    # SECTOR RANKING
    # =====================================================

    def rank_sectors(self):

        return sorted(

            self.sectors,

            key=lambda sector: sector.get(

                "change",

                0

            ),

            reverse=True

        )

    # =====================================================
    # SORT GAINERS
    # =====================================================

    def sort_gainers(

        self,

        field="change_percent"

    ):

        self.gainers.sort(

            key=lambda stock: stock.get(

                field,

                0

            ),

            reverse=True

        )

        self._update_gainers_table()

    # =====================================================
    # SORT LOSERS
    # =====================================================

    def sort_losers(

        self,

        field="change_percent"

    ):

        self.losers.sort(

            key=lambda stock: stock.get(

                field,

                0

            )

        )

        self._update_losers_table()

    # =====================================================
    # STATUS
    # =====================================================

    def set_status(

        self,

        message

    ):

        self.statusChanged.emit(

            message

        )

    # =====================================================
    # AUTO REFRESH
    # =====================================================

    def set_refresh_interval(

        self,

        seconds: int

    ):

        self.market_timer.setInterval(

            max(

                1,

                seconds

            ) * 1000

        )

    def refresh_interval(self):

        return self.market_timer.interval() // 1000

    def auto_refresh_enabled(self):

        return self.market_timer.isActive()

    # =====================================================
    # LAST UPDATE
    # =====================================================

    def last_update_text(self):

        if self.last_update is None:

            return "Never"

        return self.last_update.strftime(

            "%d-%m-%Y %H:%M:%S"

        )
        # =====================================================
    # MARKET STATISTICS
    # =====================================================

    def update_statistics(self):

        statistics = {

            "market_open":

                self.market_open,

            "indices":

                len(self.indices),

            "sectors":

                len(self.sectors),

            "gainers":

                len(self.gainers),

            "losers":

                len(self.losers),

            "last_update":

                self.last_update,

        }

        self.statisticsUpdated.emit(

            statistics

        )

        self.update_cards(

            statistics

        )

        self.update_tables()

    # =====================================================
    # DASHBOARD CARDS
    # =====================================================

    def update_cards(

        self,

        statistics

    ):

        mapping = {

            "market_status_card":

                "Open" if statistics["market_open"] else "Closed",

            "sector_count_card":

                statistics["sectors"],

            "gainers_count_card":

                statistics["gainers"],

            "losers_count_card":

                statistics["losers"],

        }

        for card_name, value in mapping.items():

            if card_name not in self.cards:

                continue

            card = self.cards[card_name]

            if hasattr(

                card,

                "set_value"

            ):

                card.set_value(

                    str(value)

                )

    # =====================================================
    # TABLE UPDATES
    # =====================================================

    def update_tables(self):

        self._update_gainers_table()

        self._update_losers_table()

        self._update_sector_table()

    # =====================================================
    # GAINERS TABLE
    # =====================================================

    def _update_gainers_table(self):

        if "gainers_table" not in self.tables:

            return

        table = self.tables["gainers_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        for stock in self.gainers:

            row = [

                stock.get("symbol", ""),

                stock.get("price", ""),

                stock.get("change", ""),

                stock.get("change_percent", ""),

                stock.get("volume", ""),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # LOSERS TABLE
    # =====================================================

    def _update_losers_table(self):

        if "losers_table" not in self.tables:

            return

        table = self.tables["losers_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        for stock in self.losers:

            row = [

                stock.get("symbol", ""),

                stock.get("price", ""),

                stock.get("change", ""),

                stock.get("change_percent", ""),

                stock.get("volume", ""),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # SECTOR TABLE
    # =====================================================

    def _update_sector_table(self):

        if "sector_table" not in self.tables:

            return

        table = self.tables["sector_table"]

        if hasattr(

            table,

            "clear_rows"

        ):

            table.clear_rows()

        ranked = self.rank_sectors()

        for sector in ranked:

            row = [

                sector.get(

                    "sector",

                    ""

                ),

                sector.get(

                    "change",

                    ""

                ),

                sector.get(

                    "advance",

                    ""

                ),

                sector.get(

                    "decline",

                    ""

                ),

            ]

            if hasattr(

                table,

                "append_row"

            ):

                table.append_row(row)

    # =====================================================
    # SEARCH
    # =====================================================

    def search_stock(

        self,

        keyword: str

    ):

        keyword = keyword.upper()

        results = []

        universe = self.gainers + self.losers

        for stock in universe:

            symbol = str(

                stock.get(

                    "symbol",

                    ""

                )

            ).upper()

            company = str(

                stock.get(

                    "company",

                    ""

                )

            ).upper()

            if keyword in symbol or keyword in company:

                results.append(stock)

        return results

    # =====================================================
    # SECTOR RANKING
    # =====================================================

    def rank_sectors(self):

        return sorted(

            self.sectors,

            key=lambda sector: sector.get(

                "change",

                0

            ),

            reverse=True

        )

    # =====================================================
    # SORT GAINERS
    # =====================================================

    def sort_gainers(

        self,

        field="change_percent"

    ):

        self.gainers.sort(

            key=lambda stock: stock.get(

                field,

                0

            ),

            reverse=True

        )

        self._update_gainers_table()

    # =====================================================
    # SORT LOSERS
    # =====================================================

    def sort_losers(

        self,

        field="change_percent"

    ):

        self.losers.sort(

            key=lambda stock: stock.get(

                field,

                0

            )

        )

        self._update_losers_table()

    # =====================================================
    # STATUS
    # =====================================================

    def set_status(

        self,

        message

    ):

        self.statusChanged.emit(

            message

        )

    # =====================================================
    # AUTO REFRESH
    # =====================================================

    def set_refresh_interval(

        self,

        seconds: int

    ):

        self.market_timer.setInterval(

            max(

                1,

                seconds

            ) * 1000

        )

    def refresh_interval(self):

        return self.market_timer.interval() // 1000

    def auto_refresh_enabled(self):

        return self.market_timer.isActive()

    # =====================================================
    # LAST UPDATE
    # =====================================================

    def last_update_text(self):

        if self.last_update is None:

            return "Never"

        return self.last_update.strftime(

            "%d-%m-%Y %H:%M:%S"

        )
        # =====================================================
    # INDEX CARDS
    # =====================================================

    def update_index_cards(self):

        mapping = {

            "nifty_card":

                self.indices.get(

                    "NIFTY",

                    {}

                ),

            "banknifty_card":

                self.indices.get(

                    "BANKNIFTY",

                    {}

                ),

            "finnifty_card":

                self.indices.get(

                    "FINNIFTY",

                    {}

                ),

            "midcap_card":

                self.indices.get(

                    "MIDCAP",

                    {}

                ),

            "vix_card":

                self.indices.get(

                    "INDIA VIX",

                    {}

                ),

        }

        for card_name, data in mapping.items():

            if card_name not in self.cards:

                continue

            card = self.cards[card_name]

            if hasattr(card, "set_value"):

                card.set_value(

                    data.get(

                        "value",

                        "--"

                    )

                )

            if hasattr(card, "set_change"):

                card.set_change(

                    data.get(

                        "change",

                        0

                    )

                )

    # =====================================================
    # MARKET BREADTH
    # =====================================================

    def update_breadth_cards(self):

        mapping = {

            "advance_card":

                self.breadth.get(

                    "advance",

                    0

                ),

            "decline_card":

                self.breadth.get(

                    "decline",

                    0

                ),

            "unchanged_card":

                self.breadth.get(

                    "unchanged",

                    0

                ),

        }

        for card_name, value in mapping.items():

            if card_name in self.cards:

                card = self.cards[card_name]

                if hasattr(

                    card,

                    "set_value"

                ):

                    card.set_value(

                        str(value)

                    )

    # =====================================================
    # SECTOR LEADERS
    # =====================================================

    def sector_leaders(self):

        if not self.sectors:

            return []

        return sorted(

            self.sectors,

            key=lambda sector: sector.get(

                "change",

                0

            ),

            reverse=True

        )[:5]

    def sector_laggards(self):

        if not self.sectors:

            return []

        return sorted(

            self.sectors,

            key=lambda sector: sector.get(

                "change",

                0

            )

        )[:5]

    # =====================================================
    # GAINERS / LOSERS
    # =====================================================

    def top_gainers(

        self,

        limit=10

    ):

        return sorted(

            self.gainers,

            key=lambda stock: stock.get(

                "change_percent",

                0

            ),

            reverse=True

        )[:limit]

    def top_losers(

        self,

        limit=10

    ):

        return sorted(

            self.losers,

            key=lambda stock: stock.get(

                "change_percent",

                0

            )

        )[:limit]

    # =====================================================
    # DASHBOARD NOTIFICATIONS
    # =====================================================

    def notify_dashboard(

        self,

        message: str

    ):

        if self.dashboard is not None:

            if hasattr(

                self.dashboard,

                "show_notification"

            ):

                self.dashboard.show_notification(

                    message

                )

        self.statusChanged.emit(

            message

        )

    # =====================================================
    # MARKET HEALTH
    # =====================================================

    def market_health(self):

        advance = self.breadth.get(

            "advance",

            0

        )

        decline = self.breadth.get(

            "decline",

            0

        )

        if advance > decline:

            sentiment = "Bullish"

        elif decline > advance:

            sentiment = "Bearish"

        else:

            sentiment = "Neutral"

        return {

            "sentiment":

                sentiment,

            "market_open":

                self.market_open,

            "indices":

                len(self.indices),

            "sectors":

                len(self.sectors),

            "gainers":

                len(self.gainers),

            "losers":

                len(self.losers),

        }

    # =====================================================
    # BACKEND SYNC
    # =====================================================

    def synchronize_backend(self):

        if hasattr(

            self.backend,

            "refresh"

        ):

            self.backend.refresh()

        elif hasattr(

            self.backend,

            "synchronize"

        ):

            self.backend.synchronize()

        self.statusChanged.emit(

            "Market backend synchronized"

        )

    # =====================================================
    # SNAPSHOT CACHE
    # =====================================================

    def cache_snapshot(self):

        self._snapshot_cache = {

            "timestamp":

                self.last_update,

            "market":

                self.market_data,

            "indices":

                self.indices,

            "breadth":

                self.breadth,

            "sectors":

                self.sectors,

            "gainers":

                self.gainers,

            "losers":

                self.losers,

        }

    def cached_snapshot(self):

        return getattr(

            self,

            "_snapshot_cache",

            {}

        )

    # =====================================================
    # COMPLETE MARKET UPDATE
    # =====================================================

    def update_dashboard(self):

        self.update_index_cards()

        self.update_breadth_cards()

        self.update_tables()

        self.cache_snapshot()

        self.notify_dashboard(

            "Market dashboard updated"

        )
            # =====================================================
    # WORKSPACE MANAGEMENT
    # =====================================================

    def save_workspace(self):

        return {

            "refresh_interval":

                self.refresh_interval(),

            "favorites":

                self.favorites(),

            "filters":

                self.filters(),

            "market_open":

                self.market_open,

            "last_update":

                self.last_update_text(),

        }

    def restore_workspace(

        self,

        workspace: Dict

    ):

        self.set_refresh_interval(

            workspace.get(

                "refresh_interval",

                5

            )

        )

        self.restore_favorites(

            workspace.get(

                "favorites",

                []

            )

        )

        self.set_filters(

            workspace.get(

                "filters",

                {}

            )

        )

    # =====================================================
    # MARKET PRESETS
    # =====================================================

    def load_preset(

        self,

        preset: str

    ):

        preset = preset.upper()

        presets = {

            "CASH": {

                "segment": "EQ",

                "volume": 1,

            },

            "F&O": {

                "segment": "FO",

                "oi": True,

                "volume": 2,

            },

            "SWING": {

                "timeframe": "1D",

                "delivery": True,

            },

            "POSITIONAL": {

                "timeframe": "1W",

                "delivery": True,

                "trend": True,

            }

        }

        if preset in presets:

            self.set_filters(

                presets[preset]

            )

            self.statusChanged.emit(

                f"{preset} preset loaded"

            )

    # =====================================================
    # FILTERS
    # =====================================================

    def set_filters(

        self,

        filters: Dict

    ):

        self._filters = filters.copy()

    def update_filter(

        self,

        key,

        value

    ):

        if not hasattr(

            self,

            "_filters"

        ):

            self._filters = {}

        self._filters[key] = value

    def remove_filter(

        self,

        key

    ):

        if hasattr(

            self,

            "_filters"

        ):

            self._filters.pop(

                key,

                None

            )

    def filters(self):

        return getattr(

            self,

            "_filters",

            {}

        )

    def clear_filters(self):

        self._filters = {}

    # =====================================================
    # FAVORITES
    # =====================================================

    def add_favorite(

        self,

        symbol: str

    ):

        if not hasattr(

            self,

            "_favorites"

        ):

            self._favorites = []

        if symbol not in self._favorites:

            self._favorites.append(symbol)

    def remove_favorite(

        self,

        symbol: str

    ):

        if hasattr(

            self,

            "_favorites"

        ):

            try:

                self._favorites.remove(symbol)

            except ValueError:

                pass

    def favorites(self):

        return getattr(

            self,

            "_favorites",

            []

        )

    def restore_favorites(

        self,

        favorites: List[str]

    ):

        self._favorites = list(

            favorites

        )

    # =====================================================
    # EXPORT / IMPORT
    # =====================================================

    def export_configuration(self):

        return {

            "filters":

                self.filters(),

            "favorites":

                self.favorites(),

            "refresh_interval":

                self.refresh_interval(),

        }

    def import_configuration(

        self,

        config: Dict

    ):

        self.set_filters(

            config.get(

                "filters",

                {}

            )

        )

        self.restore_favorites(

            config.get(

                "favorites",

                []

            )

        )

        self.set_refresh_interval(

            config.get(

                "refresh_interval",

                5

            )

        )

    # =====================================================
    # SESSION STATISTICS
    # =====================================================

    def session_statistics(self):

        return {

            "market_open":

                self.market_open,

            "indices":

                len(self.indices),

            "gainers":

                len(self.gainers),

            "losers":

                len(self.losers),

            "sectors":

                len(self.sectors),

            "last_update":

                self.last_update_text(),

        }

    # =====================================================
    # PERFORMANCE
    # =====================================================

    def performance_metrics(self):

        return {

            "refresh_duration":

                self.last_refresh_duration(),

            "auto_refresh":

                self.auto_refresh_enabled(),

            "market_open":

                self.market_open,

            "cached":

                bool(

                    self.cached_snapshot()

                ),

            "favorites":

                len(

                    self.favorites()

                ),

        }

    # =====================================================
    # DIAGNOSTICS
    # =====================================================

    def diagnostics(self):

        return {

            "cards":

                len(self.cards),

            "tables":

                len(self.tables),

            "indices":

                len(self.indices),

            "sectors":

                len(self.sectors),

            "backend":

                self.backend is not None,

            "dashboard":

                self.dashboard is not None,

            "market_open":

                self.market_open,

            "filters":

                len(

                    self.filters()

                ),

        }
        # =====================================================
    # MULTI MARKET REGISTRY
    # =====================================================

    def register_market_source(
        self,
        name: str,
        provider
    ):

        if not hasattr(self, "_market_sources"):
            self._market_sources = {}

        self._market_sources[name] = provider

    def unregister_market_source(
        self,
        name: str
    ):

        if hasattr(self, "_market_sources"):
            self._market_sources.pop(name, None)

    def market_sources(self):

        return getattr(
            self,
            "_market_sources",
            {}
        )

    # =====================================================
    # UPDATE PRIORITY
    # =====================================================

    def set_source_priorities(
        self,
        priorities: Dict[str, int]
    ):

        self._priorities = priorities.copy()

    def source_priorities(self):

        return getattr(
            self,
            "_priorities",
            {}
        )

    def ordered_sources(self):

        providers = list(
            self.market_sources().items()
        )

        priorities = self.source_priorities()

        providers.sort(
            key=lambda item: priorities.get(
                item[0],
                999
            )
        )

        return providers

    # =====================================================
    # EXECUTE ALL SOURCES
    # =====================================================

    def refresh_all_sources(self):

        merged_snapshot = {}

        for name, provider in self.ordered_sources():

            try:

                snapshot = provider.market_snapshot()

                if isinstance(snapshot, dict):

                    merged_snapshot.update(snapshot)

            except Exception as exc:

                self.log(

                    f"{name} update failed : {exc}"

                )

        if merged_snapshot:

            self.market_data = merged_snapshot

            self.last_update = datetime.now()

            self.update_indices()

            self.update_market_breadth()

            self.update_sectors()

            self.update_gainers()

            self.update_losers()

            self.update_statistics()

    # =====================================================
    # UPDATE QUEUE
    # =====================================================

    def queue_market_update(
        self,
        source: str = "default"
    ):

        if not hasattr(
            self,
            "_update_queue"
        ):

            self._update_queue = []

        self._update_queue.append(source)

    def execute_update_queue(self):

        if not hasattr(
            self,
            "_update_queue"
        ):

            return

        while self._update_queue:

            source = self._update_queue.pop(0)

            if source == "default":

                self.refresh_market()

            elif source in self.market_sources():

                try:

                    snapshot = self.market_sources()[
                        source
                    ].market_snapshot()

                    if isinstance(snapshot, dict):

                        self.market_data.update(snapshot)

                except Exception as exc:

                    self.log(

                        f"{source} queue failed : {exc}"

                    )

    def clear_update_queue(self):

        self._update_queue = []

    # =====================================================
    # ALERT RULE ENGINE
    # =====================================================

    def register_rule(
        self,
        name: str,
        callback
    ):

        if not hasattr(self, "_rules"):

            self._rules = {}

        self._rules[name] = callback

    def unregister_rule(
        self,
        name: str
    ):

        if hasattr(self, "_rules"):

            self._rules.pop(name, None)

    def evaluate_rules(self):

        if not hasattr(
            self,
            "_rules"
        ):

            return

        for rule_name, callback in self._rules.items():

            try:

                callback(self.market_data)

            except Exception as exc:

                self.log(

                    f"Rule '{rule_name}' failed : {exc}"

                )

    # =====================================================
    # EVENT BUS
    # =====================================================

    def register_event(
        self,
        event_name: str,
        callback
    ):

        if not hasattr(self, "_events"):

            self._events = {}

        self._events.setdefault(
            event_name,
            []
        ).append(callback)

    def emit_event(
        self,
        event_name: str,
        *args,
        **kwargs
    ):

        if not hasattr(self, "_events"):

            return

        for callback in self._events.get(
            event_name,
            []
        ):

            try:

                callback(*args, **kwargs)

            except Exception as exc:

                self.log(

                    f"Event '{event_name}' failed : {exc}"

                )

    # =====================================================
    # INDIA VIX / VOLATILITY
    # =====================================================

    def volatility_status(self):

        vix = self.indices.get(
            "INDIA VIX",
            {}
        ).get(
            "value",
            0
        )

        try:

            vix = float(vix)
        except Exception:
            vix = 0

        if vix < 12:

            level = "Low"

        elif vix < 18:

            level = "Normal"

        elif vix < 25:

            level = "High"

        else:

            level = "Extreme"

        return {

            "vix": vix,

            "level": level,

        }

    # =====================================================
    # MARKET RISK
    # =====================================================

    def market_risk(self):

        health = self.market_health()

        volatility = self.volatility_status()

        return {

            "sentiment":

                health["sentiment"],

            "volatility":

                volatility["level"],

            "market_open":

                self.market_open,

        }

    # =====================================================
    # CONTROLLER MONITOR
    # =====================================================

    def controller_monitor(self):

        return {

            "market_sources":

                len(self.market_sources()),

            "queued_updates":

                len(

                    getattr(

                        self,

                        "_update_queue",

                        []

                    )

                ),

            "rules":

                len(

                    getattr(

                        self,

                        "_rules",

                        {}

                    )

                ),

            "events":

                len(

                    getattr(

                        self,

                        "_events",

                        {}

                    )

                ),

            "market_open":

                self.market_open,

            "last_refresh":

                self.last_refresh_duration(),

        }

    # =====================================================
    # BACKEND COORDINATION
    # =====================================================

    def synchronize_backend_modules(self):

        if hasattr(

            self.backend,

            "synchronize"

        ):

            self.backend.synchronize()

        elif hasattr(

            self.backend,

            "refresh"

        ):

            self.backend.refresh()

        self.statusChanged.emit(

            "Market modules synchronized"

        )
            # =====================================================
    # SESSION LIFECYCLE
    # =====================================================

    def start_session(self):

        self._session_active = True
        self._session_started = datetime.now()

        self.start()

        self.statusChanged.emit(
            "Market session started"
        )

    def stop_session(self):

        self.stop()

        self._session_active = False
        self._session_ended = datetime.now()

        self.statusChanged.emit(
            "Market session stopped"
        )

    def session_active(self):

        return getattr(
            self,
            "_session_active",
            False
        )

    def session_duration(self):

        if not getattr(
            self,
            "_session_started",
            None
        ):
            return 0

        end_time = getattr(
            self,
            "_session_ended",
            datetime.now()
        )

        return (
            end_time -
            self._session_started
        ).total_seconds()

    # =====================================================
    # THEME SYNCHRONIZATION
    # =====================================================

    def synchronize_theme(self):

        theme = current_theme()

        for card in self.cards.values():

            if hasattr(
                card,
                "apply_theme"
            ):

                card.apply_theme(theme)

        for table in self.tables.values():

            if hasattr(
                table,
                "apply_theme"
            ):

                table.apply_theme(theme)

        self.statusChanged.emit(
            "Theme synchronized"
        )

    # =====================================================
    # HEALTH MONITOR
    # =====================================================

    def controller_health(self):

        healthy = True

        issues = []

        if self.backend is None:

            healthy = False

            issues.append(
                "Backend unavailable"
            )

        if self.dashboard is None:

            healthy = False

            issues.append(
                "Dashboard unavailable"
            )

        if len(self.cards) == 0:

            issues.append(
                "No dashboard cards found"
            )

        if len(self.tables) == 0:

            issues.append(
                "No dashboard tables found"
            )

        return {

            "healthy": healthy,

            "issues": issues,

            "market_open": self.market_open,

            "last_update": self.last_update_text(),

        }

    # =====================================================
    # ERROR RECOVERY
    # =====================================================

    def recover(self):

        self.statusChanged.emit(
            "Recovering controller..."
        )

        try:

            self.stop()

        except Exception:

            pass

        try:

            self.start()

        except Exception as exc:

            self.log(
                f"Recovery failed : {exc}"
            )

        else:

            self.statusChanged.emit(
                "Recovery completed"
            )

    # =====================================================
    # RESET
    # =====================================================

    def reset(self):

        self.market_data = {}

        self.indices = {}

        self.breadth = {}

        self.sectors = []

        self.gainers = []

        self.losers = []

        self.last_update = None

        self.clear_filters()

        self._favorites = []

        self.statusChanged.emit(
            "Controller reset"
        )

    # =====================================================
    # MODULE REGISTRATION
    # =====================================================

    def register_module(
        self,
        name: str,
        module
    ):

        if not hasattr(
            self,
            "_modules"
        ):

            self._modules = {}

        self._modules[name] = module

    def unregister_module(
        self,
        name: str
    ):

        if hasattr(
            self,
            "_modules"
        ):

            self._modules.pop(
                name,
                None
            )

    def modules(self):

        return getattr(
            self,
            "_modules",
            {}
        )

    # =====================================================
    # SERIALIZATION
    # =====================================================

    def serialize_state(self):

        return {

            "market_open":
                self.market_open,

            "indices":
                self.indices,

            "breadth":
                self.breadth,

            "sectors":
                self.sectors,

            "gainers":
                self.gainers,

            "losers":
                self.losers,

            "favorites":
                self.favorites(),

            "filters":
                self.filters(),

            "last_update":
                self.last_update_text(),

        }

    def restore_state(
        self,
        state: Dict
    ):

        self.market_open = state.get(
            "market_open",
            False
        )

        self.indices = state.get(
            "indices",
            {}
        )

        self.breadth = state.get(
            "breadth",
            {}
        )

        self.sectors = state.get(
            "sectors",
            []
        )

        self.gainers = state.get(
            "gainers",
            []
        )

        self.losers = state.get(
            "losers",
            []
        )

        self.restore_favorites(
            state.get(
                "favorites",
                []
            )
        )

        self.set_filters(
            state.get(
                "filters",
                {}
            )
        )

    # =====================================================
    # SUMMARY
    # =====================================================

    def controller_summary(self):

        return {

            "session_active":
                self.session_active(),

            "market_open":
                self.market_open,

            "health":
                self.controller_health(),

            "performance":
                self.performance_metrics(),

            "statistics":
                self.session_statistics(),

            "sources":
                len(
                    self.market_sources()
                ),

            "modules":
                len(
                    self.modules()
                ),

        }

    # =====================================================
    # CLEANUP
    # =====================================================

    def cleanup(self):

        self.stop()

        self.clear_update_queue()

        self._events = {}

        self._rules = {}

        self._modules = {}

        self.statusChanged.emit(
            "Market controller cleaned up"
        )
        # =====================================================
# FACTORY
# =====================================================

def create_market_controller(
    dashboard=None,
    backend=None,
    parent=None
):

    controller = MarketController(
        dashboard=dashboard,
        backend=backend,
        parent=parent
    )

    return controller


# =====================================================
# VERSION
# =====================================================

CONTROLLER_NAME = "MarketController"

CONTROLLER_VERSION = "4.0.0"

CONTROLLER_AUTHOR = "StockVersity Scanner Pro"

CONTROLLER_DESCRIPTION = (
    "Central controller responsible for market "
    "updates, dashboard synchronization, "
    "statistics, alerts, sector monitoring, "
    "market breadth and live data management."
)


# =====================================================
# MODULE METADATA
# =====================================================

MODULE_INFO = {

    "name":
        CONTROLLER_NAME,

    "version":
        CONTROLLER_VERSION,

    "author":
        CONTROLLER_AUTHOR,

    "description":
        CONTROLLER_DESCRIPTION,

    "supports": [

        "NSE",

        "Market Breadth",

        "Sector Rotation",

        "Top Gainers",

        "Top Losers",

        "India VIX",

        "Dashboard",

        "Background Refresh",

        "Alert Rules",

        "Session Management",

        "Theme Synchronization",

        "Workspace",

        "Diagnostics",

        "State Persistence",

    ],

}


# =====================================================
# MONKEY PATCH HELPERS
# =====================================================

def controller_version():

    return CONTROLLER_VERSION


def controller_name():

    return CONTROLLER_NAME


def controller_info():

    return MODULE_INFO.copy()


# =====================================================
# CLASS HELPERS
# =====================================================

def _marketcontroller_str(self):

    return (
        f"{CONTROLLER_NAME}"
        f"(market_open={self.market_open}, "
        f"indices={len(self.indices)}, "
        f"sectors={len(self.sectors)}, "
        f"gainers={len(self.gainers)}, "
        f"losers={len(self.losers)})"
    )


def _marketcontroller_repr(self):

    return (
        f"<{CONTROLLER_NAME} "
        f"version={CONTROLLER_VERSION} "
        f"market_open={self.market_open}>"
    )


MarketController.__str__ = _marketcontroller_str

MarketController.__repr__ = _marketcontroller_repr


# =====================================================
# DEFAULT SETTINGS
# =====================================================

DEFAULT_MARKET_SETTINGS = {

    "refresh_interval": 5,

    "auto_retry": True,

    "background_updates": True,

    "cache_snapshots": True,

    "show_notifications": True,

    "market_start": "09:15",

    "market_end": "15:30",

    "timezone": "Asia/Kolkata",

}


# =====================================================
# EXPORTS
# =====================================================

__all__ = [

    "MarketController",

    "MarketWorker",

    "create_market_controller",

    "controller_version",

    "controller_name",

    "controller_info",

    "MODULE_INFO",

    "DEFAULT_MARKET_SETTINGS",

]